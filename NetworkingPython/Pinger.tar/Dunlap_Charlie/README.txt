

usage in windows cmd 
endian = Little
logfile not grades so not implemented 

not listed on the assignment so:
	time is rounded to ints 
	%loss is rounded to ints



output is according to: 
-------------------------------------------------------------------------------------------------------------------
Example:
>[user@laptop:~] sudo pinger –p “hello” –c 4 -d 206.190.36.45
>Pinging 206.190.36.45 with 5 bytes of data “hello”
>Reply from 206.190.36.45: bytes=5 time=69ms TTL=47
>Reply from 206.190.36.45: bytes=5 time=70ms TTL=47
>Reply from 206.190.36.45: bytes=5 time=69ms TTL=47
>Reply from 206.190.36.45: bytes=5 time=69ms TTL=47
>Ping statistics for 206.190.36.45: Packets: Sent = 4, Received =4, Lost = 0 (0% loss),
Approximate round trip times in milli-seconds: Minimum = 69ms, Maximum = 70ms,
Average = 69ms
-------------------------------------------------------------------------------------------------------------------


tested on google.com
test example from home network:

C:~>python pinger.py -p hello -c 5 -d google.com -l no
Pinging 172.217.4.174 with 5 bytes of data 'hello'
Reply from 172.217.4.174: bytes=5 time=11ms TTL=54
Reply from 172.217.4.174: bytes=5 time=8ms TTL=54
Reply from 172.217.4.174: bytes=5 time=8ms TTL=54
Reply from 172.217.4.174: bytes=5 time=9ms TTL=54
Reply from 172.217.4.174: bytes=5 time=8ms TTL=54
Ping statistics for 172.217.4.174: Packets: Sent = 5, Received = 5, Lost = 0 (0% loss)
Approximate round trip times in milli-seconds: Minimum = 8ms, Maximum = 11ms, Average = 8ms


no compile 
