#A2 client
#Charlie Dunlap
#assignment for networking
#mimics ping console command
#output according to assignment 

import socket 
import sys
import argparse
import select
import time
import struct
import os
import array
import collections

#used global value
#idealy would not but small limited scope progam should be fine
startTimes = []
endTimes = []
TTLs = []
tripTimes = []
lostPacks = 0

#bit manip sum
def getSum(sum):
    sum &= ~(0x00) 
    sum = (sum >> 16) + (sum & 0xffff) 
    return (~(sum + (sum >> 16)) & 0xffff)


#calc checksum for packet
def getChecksum(payload):
    #convert to array of bytes
    #https://stackoverflow.com/questions/11624190/python-convert-string-to-byte-array
    #array.array(typecode[, initializer])
    #A new array whose items are restricted by typecode, 
    # and initialized from the optional initializer value
    if (len(payload) % 2 == 1):
        payload += "\x00".encode("utf-8")
        bytePair = array.array("h", payload)
        sum = 0
        pos = 0
        leng = len(bytePair) 
        while pos < leng:
            sum += (bytePair[pos])
            #print(sum)
            pos += 1
        return socket.htons(getSum(sum))
    else:    
        bytePair = array.array("B", payload)
        sum = 0 
        pos = 0
        leng = len(bytePair) 
        while pos < leng:
            sum += (bytePair[pos])
            #print(sum)
            pos += 1
        return socket.htons(getSum(sum))


#do the pinging work
def pinger( payload, count, destination):

    pingsock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.getprotobyname('icmp'))
    pingTarget = socket.gethostbyname(destination)
    
    icmpHeader = struct.pack('bbHHH', 8, 0, 0, os.getpid(), 12345) 
    icmpPayload = payload.encode('utf-8')
    packetSize = icmpHeader + icmpPayload
    
    checksum = socket.htons(getChecksum(packetSize))
    icmpHeader = struct.pack('bbHHH', 8, 0, checksum, os.getpid(), 12345)
    pingPacket = (icmpHeader + icmpPayload) 
    bytesSize = len(payload)
    
    print("Pinging {} with {} bytes of data '"'{}'"' ".format(pingTarget, bytesSize, payload))
    #for i in count:
    counter = count
    pos = 0
    while counter > 0:
        #print("doing ping")
        ping(pingsock,pingPacket,pingTarget,counter)
        counter = counter-1
        
        tripTime = int((endTimes[pos] - startTimes[pos]) *1000.0)
        tripTimes.append(tripTime)

        thisTTL = TTLs[pos]
        print("Reply from {}: bytes={} time={}ms TTL={}".format(pingTarget,bytesSize, tripTime, thisTTL ))
        pos = pos + 1
        time.sleep(1)
    
    summary(pingTarget,pos)        


#summary printing
def summary(pingTarget,pos):
    global lostPacks
    rec = 0
    for t in tripTimes :
        if (t == 0):
            lostPacks += 1
        else:
            rec = rec + 1    

    maxRTT = max(tripTimes)
    minRTT = min(tripTimes)
    avgRTT = int(sum(tripTimes)/pos)
    perLoss = int((float(lostPacks/pos)*100))
    
    print("Ping statistics for {}: Packets: Sent = {}, Received = {}, Lost = {} ({}% loss)".format(pingTarget,pos,rec,lostPacks,perLoss))
    print("Approximate round trip times in milli-seconds: Minimum = {}ms, Maximum = {}ms, Average = {}ms".format(minRTT,maxRTT,avgRTT))
        

#do a ping cycle send and rcv
def ping(pSock,pPacket,pTarget,position):
    startTime = time.time()
    startTimes.append(startTime)
    pSock.sendto(pPacket, (pTarget,0))
    getResponce(pSock,position)


#select statment to get echo reply
def getResponce(psock, position):
    while True:
        getRcv = select.select([psock], [], [], 3)
        timeReceived = time.time()
        if getRcv[0] == []:
            return "Request timed out."
        
        recPacket, addr = psock.recvfrom(2048)
        #print("got something!!")
        icmpHeader = struct.unpack('B', recPacket[20:21])
        if (icmpHeader[0] != 0):
            print("wrong packet")
            return 
        if (icmpHeader[0] ==0):
            #print("got it!")
            #individual ttl can be grabbed from ip header
            ipHeader = struct.unpack('bbhhhb' , recPacket[:9])
            TTL = ipHeader[5]
            #print("ttl",TTL)
            TTLs.append(TTL)
            endTimes.append(timeReceived)
            return


if __name__ == '__main__': 
               
    if len(sys.argv) < 3:
        print("pinger -p payload -c count -d destination -l logfile")
        sys.exit()

    parse = argparse.ArgumentParser(description=' pinger -p payload -c count -d destination -l logfile')
    parse.add_argument('-p', '--payload', required=True)
    parse.add_argument('-c', '--count', type = int, nargs='?' ,const=10)
    parse.add_argument('-d', '--destination', required=True)
    parse.add_argument('-l', '--logfile' )
    
    args = parse.parse_args()
    
    if(args.count == None or args.count == 0):
        args.count = 10
       
    #logfile not graded so not implemented =)
    #logfile = open(log,"w")
    try: 
        pinger(args.payload,args.count,args.destination)
    except: 
        sys.exit()    

    sys.exit()