

usage in windows cmd 
no compile 

dijkstra and mst test against test case:
6
A : [B,1]
B : [C,3], [E,2]
C : [D,5], [F,6]
E : [F,3]
F : [G,2]
D : [F,2] 
A
G 

both work on given test case correctly