# A3 mst
# Charlie Dunlap
# assignment for networking
# mst functions carried over from dijkstras
# stubbed function starters = xyz_abc

import argparse
import sys
import re


class Edge():
    def __init__(self, start, end, cost):
        self.start = start
        self.end = end
        self.cost = cost


class Node():
    def __init__(self, name):
        self.name = name
        self.edges = []
        self.parent = ''
    
    def addEdge(self, start, end, cost):
        e = Edge(start, end, cost)
        self.edges.append(e)

    def addMadeEdge(self, edge):
        self.edges.append(edge)    

    def addParent(self,parent):
        self.parent = parent

    def getEdges(self):
        return self.edges


def readFile(fileName):
    graph = []
    inFile = open(fileName, "r")
    inputLines = inFile.readlines()
    numberInstructions = int(inputLines[0])

    count = 1
    while count < numberInstructions+1:
        graph.append(inputLines[count])

        count += 1
    
    return graph # You may add other variables to be returned


def MakeGraph(graph):
    # add node and edges from node
    nodeCount = 0
    nodeByName = []
    nodes = []
    edgeList = []
    for g in graph:
        nodeName = g[0]
        try :
            nodeByName.index(nodeName)
        except ValueError:
            nodeCount+=1
            nodeByName.append(nodeName)

        line = g.split('[')
        node = Node(nodeName)
        position = 1
        while(position < len(line)):
            s = line[position]
            endName = s[0]

            costExtract = [int(i) for i in re.findall(r'\d+', s)]
            cost = int(costExtract[0])
            
            try :
                nodeByName.index(endName)
            except ValueError:
                nodeCount+=1
                nodeByName.append(endName)
                

            node.addEdge(nodeName, endName, cost)
            edgeList.append(Edge(nodeName, endName, cost))

            position += 1
        nodes.append(node)

    return nodes, edgeList, nodeCount,nodeByName


def findParent(node,parents):
    if parents[node] != node:
        parents[node] = findParent(parents[node],parents)
    
    return parents[node]


def join(start, end, edgeList, parents,join):
    soul = findParent(start,parents)
    mate = findParent(end,parents)
    if soul != mate:# =(
        for e in edgeList:
            join+=1
            parents[soul] = mate


def run_mst(graph):
    selectedNodes = set()
    parents = dict()
    nodeGraph, edgeList, nodeCount, nodeByName = MakeGraph(graph)
    #some carry over from differnt attempts in makegraph
    #left in for personal referance 
    selectedCount = 0
    joinCount = 0
    for n in nodeByName:
        parents[n] = n
    #print(parents)
    #yay lambda sort!
    es = sorted(edgeList,key=lambda edge: (edge.cost, edge.start, edge.end))
    #edges are sorted by cost then alpha
    #start at first edge check its parents for cycle update parents 
    for e in es:
        if findParent(e.start,parents) != findParent(e.end,parents):
            selectedNodes.add(e)
            join(e.start,e.end,es,parents,joinCount)
            selectedCount+=1
    #print(joinCount)        
    if(selectedCount==nodeCount-1):
        selected = sorted(selectedNodes,key=lambda edge: (edge.cost, edge.start, edge.end))
    
        result = selected 
        return result
    else:
        print("mst failed? check output") 
        selected = sorted(selectedNodes,key=lambda edge: (edge.cost, edge.start, edge.end))
    
        result = selected 
        return result   

def print_output(result, filename):
    outfile = open(filename, "w")
    for r in result:
        print(r.cost,r.start,r.end) 
        outfile.write("{} {} {} \n".format(r.cost,r.start,r.end))  
    outfile.close()
    #Write strings as mentioned in 'expected output' seciton in the assignment

def start_mst(iFile):
    graph = readFile(iFile)
    result = run_mst(graph)
    print_output(result, 'output_mst.txt')

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("mst -i inputFile")
        sys.exit()

    parse = argparse.ArgumentParser(description=' mst -i inputFile')
    parse.add_argument('-i', '--inputFile', required=True)

    args = parse.parse_args()
    start_mst(args.inputFile)

    sys.exit()
