# A3 dijkstra
# Charlie Dunlap
# assignment for networking
# dijkstra

import argparse
import sys
import re


class Edge():
    pass

    def __init__(self, start, end, cost):
        self.start = start
        self.end = end
        self.cost = cost


class Node():
    pass

    def __init__(self, name):
        self.name = name
        self.edges = []

    def addEdge(self, start, end, cost):
        e = Edge(start, end, cost)
        self.edges.append(e)

    def getEdges(self):
        return self.edges


def readFile(fileName):
    graph = []
    inFile = open(fileName, "r")
    inputLines = inFile.readlines()
    numberInstructions = int(inputLines[0])

    count = 1
    while count < numberInstructions+1:
        graph.append(inputLines[count])

        count += 1
    source = inputLines[count].rstrip()
    destination = inputLines[count + 1].rstrip()

    return graph, source, destination  # You may add other variables to be returned


def MakeGraph(graph):
    # add node and edges from node
    nodes = []
    edgeList = []
    for g in graph:
        nodeName = g[0]

        line = g.split('[')
        node = Node(nodeName)
        position = 1
        while(position < len(line)):
            s = line[position]
            endName = s[0]

            costExtract = [int(i) for i in re.findall(r'\d+', s)]
            cost = int(costExtract[0])

            node.addEdge(nodeName, endName, cost)
            edgeList.append(Edge(nodeName, endName, cost))

            position += 1
        nodes.append(node)

    return nodes, edgeList


def run_dijkstra(graph, sn, dn):
    # Run Algo
    nodeGraph, edgeList = MakeGraph(graph)
    startNode = nodeGraph[0]
    endNode = nodeGraph[0]

    for n in nodeGraph:
        if n.name == sn:
            startNode = n
    nodeSet = [startNode]
    distanceSet = {}
    pathList = []
    for e in edgeList:
        if e.start == startNode.name:
            distanceSet[e] = e.cost
        else:
            distanceSet[e] = float('inf')

    while(len(nodeSet) != len(nodeGraph)):
        minEdgeCost = float('inf')
        edgeIndex = -1
        nodeIndex = -1
        toAddName = ''
        pickedEdge = Edge('zzz', 'zzz', 999)
        for e, c in distanceSet.items():
            for n in nodeSet:
                name = n.name

                if c < minEdgeCost and e.end != name:

                    pickedEdge = e
                    minEdgeCost = c
                    toAddName = e.end

        pathList.append(pickedEdge)
        distanceSet.pop(pickedEdge)

        for n in nodeGraph:
            if(n.name == toAddName):
                nodeIndex = nodeGraph.index(n)

        if(nodeGraph[nodeIndex] not in nodeSet):
            nodeSet.append(nodeGraph[nodeIndex])

        for e, c in distanceSet.items():

            if(e.start == toAddName):
                edgeListIndex = edgeList.index(e)
                newCost = edgeList[edgeListIndex].cost + minEdgeCost
                if(newCost < c):
                    distanceSet[e] = newCost

    path = []
    parent = ''
    dest = False

    while(parent != sn):
        for e in pathList:
            if dest == False:
                if e.end == dn:
                    dest = True
                    path.append(e)
                    parent = e.start

            if e.end == parent:
                path.append(e)
                parent = e.start
    path.reverse()

    result = path  # Find path from source node to destination node
    return result


def print_output(result, filename):
    outfile = open(filename, "w")
    sum = 0
    res = ''
    for r in result:
        sum += r.cost
        res += r.start
        res += " -"
        res += str(r.cost)
        res += "-> "
    res += result[len(result)-1].end
    print(res)
    print(sum)
    outfile.write(res+"\n")
    outfile.write(str(sum))
    outfile.close()
    # Write strings as mentioned in 'expected output' seciton in the assignment


def start_dijkstra(iFile):
    graph, sn, dn = readFile(iFile)
    result = run_dijkstra(graph, sn, dn)
    print_output(result, 'output_dijkstra.txt')


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("dijkstra -i inputFile")
        sys.exit()

    parse = argparse.ArgumentParser(description=' dijkstra -i inputFile')
    parse.add_argument('-i', '--inputFile', required=True)

    args = parse.parse_args()
    start_dijkstra(args.inputFile)

    sys.exit()
