#A1 server
#Charlie Dunlap

import sys
from sys import argv
import socket
from _thread import *
import threading
import argparse
import pickle
import queue
import os


def udprecv(recsock, serverAddress):
    #print("udp recv")
    while True:
            try:
                data, Saddress = ssock.recvfrom(4096)
                recvQue.put((data,Saddress))     
            except KeyboardInterrupt:
                try:
                    
                    print("terminating server...2")
                    logfile.write("terminating server… \n")
                    logfile.close()
                    os._exit(1)
                    #ssock.close
                    sys.exit()
                except:
                    os._exit(1)
                    pass
            except:
                pass


def server():
    
        threading.Thread(target=udprecv,args=(ssock,serveradd)).start()
        while True:
            try: 
                while not recvQue.empty():
                    data, Saddress = recvQue.get()
                    if data:
                        #reg server func 
                        unpacked = pickle.loads(data)
                        m = unpacked[0]
                        s = m.split(" ")
                        if s[0] == '':
                            print("empty recv")
                        elif s[0] == "register":
                            #output for terminal
                            print("{} registered from host {} port {} ...".format(unpacked[1], Saddress[0],Saddress[1]))
                            #client connection from host 127.0.0.1 port 57886
                            logfile.write("client connection from host {} port {} \n".format( Saddress[0],Saddress[1]))
                            logfile.write("received register {} from host {} port {} \n".format(unpacked[1], Saddress[0],Saddress[1]))
                            message = "welcome" + " " + unpacked[1]
                            clients[unpacked[1]] = Saddress
                            sent = ssock.sendto(message.encode("utf-8"), Saddress)
                        elif s[0] == "sendto":
                            b = False
                            for client in clients:
                                if client == s[1]:
                                    b = True
                            if b == True:
                                tobreak = unpacked[1].split(" ")
                                text = ""
                                for word in tobreak:
                                    if word != s[1] and word != s[0]:
                                        text += word
                                        text += " "
                                m = ("recvfrom" +" "+ s[2] + " "+ text)
                                logfile.write(s[0]+" "+s[1]+" from "+s[2]+" " +text+"\n")
                                ssock.sendto(m.encode("utf-8"),clients[s[1]])
                                logfile.write("recvfrom" +" "+ s[2] + " to "+ s[1]+" "+ text+"\n") 
                            elif b == False:
                                
                                tobreak = unpacked[1].split(" ")
                                text = ""
                                for word in tobreak:
                                    if word != s[1] and word != s[0]:
                                        text += word
                                        text += " "
                                logfile.write(s[0]+" "+s[1]+" from "+s[2]+" " +text+"\n")
                                logfile.write(s[1]+" not registered with server \n")        
                                logfile.write("sending message to server overlay {} \n".format(text))        
                                tcpMSGpass(data)

                        elif s[0] == "disconnect":
                            print("got disconnect")
       
            except KeyboardInterrupt:      
                try:
                    print("terminating server...")
                    logfile.write("terminating server… \n")
                    logfile.close()
                    #socket.close()
                    os._exit(1)
                    sys.exit()
                except:
                    os.exit(1)
                    sys.exit()
       
                return False
            except:
                pass


def tcpMSGpass(mtopass):
    try:
        for s in servers:
            if s != None:
                #print(s)
                s.send(mtopass)
    except:
        pass


def tcprecv(rsock):
    while True:
        try:
            data = rsock.recv(4096)
            if data:
                    try:
                        unpacked = pickle.loads(data)
                        m = unpacked[0]
                        s = m.split(" ")
                        if s[0] == '':
                            print("")
                        elif s[0] == "sendto":
                            b = False
                            for client in clients:
                                if client == s[1]:
                                    b = True
                            if b == True:
                                tobreak = unpacked[1].split(" ")
                                text = ""
                                for word in tobreak:
                                    if word != s[1] and word != s[0]:
                                        text += word
                                        text += " "
                                m = ("recvfrom" +" "+ s[2] + " "+ text)
                                logfile.write(s[0]+" "+s[1]+" from "+s[2]+" " +text+"\n")
                                ssock.sendto(m.encode("utf-8"),clients[s[1]])
                                logfile.write("recvfrom" +" "+ s[2] + " to "+ s[1]+" "+ text+"\n") 
                            elif b == False:
                                
                                tobreak = unpacked[1].split(" ")
                                text = ""
                                for word in tobreak:
                                    if word != s[1] and word != s[0]:
                                        text += word
                                        text += " "
                                logfile.write(s[0]+" "+s[1]+" from "+s[2]+" " +text+"\n")
                                logfile.write(s[1]+" not registered with server \n")        
                                logfile.write("sending message to server overlay {} \n".format(text))        
                                tcpMSGpass(data)    
                        # elif s[0] == "sendto":
                        #     b = False
                        #     for client in clients:
                        #         if client == s[1]:
                        #             b = True
                        #     if b == True:
                        #         tobreak = unpacked[1].split(" ")
                        #         text = ""
                        #         for word in tobreak:
                        #             if word != s[1] and word != s[0]:
                        #                 text += word
                        #                 text += " "
                        #         m = ("recvfrom" +" "+ s[2] + " "+ text)
                        #         logfile.write("recvfrom" +" "+ s[2] + " to "+ s[1]+" "+ text+"\n")
                        #         ssock.sendto(m.encode("utf-8"),clients[s[1]]) 
                        #     elif b == False:
                                
                        #         tcpMSGpass(data)   
                        # elif s[0] == "sendto":
                        #     b = False
                        #     for client in clients:
                        #         if client == s[1]:
                        #             b = True
                        #     if b == True:
                        #         tobreak = packed[1].split(" ")
                        #         text = ""
                        #         for word in tobreak:
                            
                        #             if word != s[1] and word != s[0]:
                        #                 text += word
                        #                 text += " "
                        #         m = ("recvfrom" +" "+ s[1] + " "+ text)          
                        #         ssock.sendto(m.encode("utf-8"),clients[s[1]])
                        #     elif b == False:
                        #         for s in servers:
                        #             s.send(data)
                    except:
                        pass                
        except:
            pass



def overlayRCV(socketTCP):
    #print("oRECV")
    while True:
        try:
            new_server_socket, new_server_address = socketTCP.accept()
            try:
                so = servers.index(new_server_socket)
            except ValueError: 
                servers.append(new_server_socket)
                logfile.write("server joined overlay from {} port {} \n".format(new_server_address[0],new_server_address[1]))
            try:
                s = threading.Thread(target=tcprecv, args=(new_server_socket,), daemon=True)
                s.start()       
            except:      
                pass
        except:
            pass    


if __name__ == '__main__':

    if len(sys.argv) < 2:
        print("server.py -s serveroverlayIP -t serveroverlayport -o overlayport –p portno –l logfile")
        sys.exit()
    parse = argparse.ArgumentParser(description=("server –s serveroverlayIP –t serveroverlayport –o overlayport –p portno –l logfile"))
    parse.add_argument('-s', '--serveroverlayIP',required=False)
    parse.add_argument('-t', '--serveroverlayport',required=False)
    parse.add_argument('-o', '--overlayport',required=False)
    parse.add_argument('-p', '--portno',required=True)
    parse.add_argument('-l', '--logfile',required=True)
    args = parse.parse_args()

    log = args.logfile
    port = int(args.portno)
    logfile = open(log,"w")
    recvQue = queue.Queue()
    clients = {}
    servers = []
    
    #udp socket
    ssock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    overlay_socket_con = None
    overlay_socket_recv = None
    serveradd = ('localhost', port)
    ssock.bind(serveradd)
    
    #single server no overlay
    if args.serveroverlayIP == None and args.serveroverlayport == None and args.overlayport == None:
        try:
            print("server started on {} at port {}...".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
            logfile.write("server started on {} at port {}... \n".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
       
            running = server()
            if running == False:
                try:
                    #ssock.close()
                    logfile.close()
                    sys.exit()
                except:
                    pass

        except KeyboardInterrupt:
            try:
                print("terminating server...")
                logfile.write("terminating server… \n")
                logfile.close()
                os._exit(1)
                sys.exit()
            except:
                os._exit(1)
                sys.exit()
    #first server with overlay
    elif args.serveroverlayIP == None and args.serveroverlayport == None:
        try:
            overlay_socket_recv = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            overlay_socket_recv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            oladd = ('localhost',int(args.overlayport))
            overlay_socket_recv.bind(oladd)
            overlay_socket_recv.listen()
            print("server started on {} at port {}...".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
            #formated vs non formated print strings 
            logfile.write("server started on {} at port {}... \n".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
            logfile.write("server overlay started at port "+args.overlayport + "\n")
    
            try:
                r = threading.Thread(target=overlayRCV, args=(overlay_socket_recv,), daemon=True)
                r.start()     
            except:
                print("thread except")
            try:   
                running = server()
                if running == False:
                    try:
                        #ssock.close()
                        logfile.close()
                        sys.exit()
                    except:
                        pass
            except KeyboardInterrupt:
                print("terminating server...")
                logfile.write("terminating server…\n")
                logfile.close()
                sys.exit()         
        except KeyboardInterrupt:
            print("terminating server...")
            logfile.write("terminating server…\n")
            logfile.close()
            sys.exit()
        except:
            try:
                #print("terminating server...7")
                logfile.write("terminating server… \n")
                logfile.close()
                os._exit(1)
                sys.exit()
            except:
                os._exit(1)
                sys.exit()
                pass    
    #second server to overlay with added overlay     
    elif args.serveroverlayIP != None and args.serveroverlayport != None and args.overlayport != None:
        try:
            overlay_socket_con = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            olcon = (args.serveroverlayIP,int(args.serveroverlayport))
            overlay_socket_con.connect(olcon)
            print("server started on {} at port {}...".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
            logfile.write("server started on {} at port {}...\n".format(ssock.getsockname()[0],ssock.getsockname()[1] ))
            logfile.write("server overlay started at port "+args.overlayport + "\n")
            try:  
                s = threading.Thread(target=tcprecv, args=(overlay_socket_con,), daemon=True)          
                s.start()       
            except:
                print("except")    
            
            overlay_socket_con.setblocking(False)
            servers.append(overlay_socket_con)

            #open fo overlay recv
            overlay_socket_recv = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            overlay_socket_recv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            oladd = ('localhost',int(args.overlayport))
            overlay_socket_recv.bind(oladd)
            overlay_socket_recv.listen()
            try:
                r = threading.Thread(target=overlayRCV, args=(overlay_socket_recv,), daemon=True)
                r.start()
            except:
                print("threads?!?")    
            try:   
                running = server()
                if running == False:
                    try:
                        ssock.close()
                        logfile.close()
                        sys.exit()
                    except:
                        pass

            except KeyboardInterrupt:
                #print("closing333444")
                print("terminating server...")
                logfile.write("terminating server… \n")
                logfile.close()
                sys.exit()
        except:
                try:
                    print("second server needs an overlay server, please check usage")
                    #print("something broke 00")
                    #print("terminating server...1")
                    logfile.write("terminating server… \n")
                    logfile.close()
                    os._exit(1)
                    sys.exit()
                except:
                    os._exit(1)
                    sys.exit()
                    pass    


