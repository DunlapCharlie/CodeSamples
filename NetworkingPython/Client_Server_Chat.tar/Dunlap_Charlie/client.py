#A1 client
#Charlie Dunlap

import sys
from sys import argv
import socket
import threading
from _thread import *
import argparse
import pickle

 
def recvMSG(csock, serverAddress):
    #while True:
    recvsock = csock
    print("connected to server and registered")
    print("waiting for messages..")
    while True:
        try:
            data, server = recvsock.recvfrom(4096)
            if data:
                s = data.decode("utf-8")
                if s != "" and s != "\n":
                    print(s)
                sp=s.split(" ")
                com = sp[0]
                fro = sp[1]
                text = ""
                for word in sp:
                    if word != sp[0] or word != sp[1]:
                        text += word
                        text += " "
                # logfile.write(com + " "+fro+" "+text+"\n")
                logfile.write(text+"\n")
        except:
            pass

        
def client(server,port,name):
    csock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    server_add = (server,port)
    logfile.write("connecting to the server {} at port {} \n".format(server,port))
    dataToSend = ("register", name)
    message = pickle.dumps(dataToSend)
    logfile.write("sending register message {} \n".format(name))
    sent = csock.sendto(message,server_add)

    data, server = csock.recvfrom(4096)
    if data:
        logfile.write("received welcome \n")
        try:
            #thread to get messages 
            r = threading.Thread(target=recvMSG, args=(csock,server_add), daemon=True)
            r.start()
            #loop to send
            while True:
                m = input()
                if m == '':
                    continue
                if m== 'exit':
                    logfile.write("terminating client… \n")
                    break
                s = m.split(" ")
                target = s[1]
                commandMSG = (s[0]+" "+s[1]+" "+name)
                text = ""
                for word in s:
                    if word != s[0] or word != s[1]:
                        text += word
                        text += " "
                #logfile.write("sendto {} ".format(target,) + text + "\n")
                logfile.write( text + "\n")
                
                toSend = (commandMSG, text)
                message = pickle.dumps(toSend)
                csock.sendto(message,server_add)
        except KeyboardInterrupt:     
            try:
                print("exit")
                logfile.write("terminating client… \n")
                toSend = ("disconnect", "disconnect")   
                message = pickle.dumps(toSend)
                csock.sendto(message,server_add)
                csock.close()
                logfile.close()
                sys.exit()
            except: 
                pass
    else:
        print("failed to connect")
        csock.close()
        sys.exit()        
    try:
        print("exit")
        toSend = ("disconnect", "disconnect")   
        message = pickle.dumps(toSend)
        csock.sendto(message,server_add)
        csock.close()
        logfile.close()
        sys.exit()
    except: 
        pass

                
             

if __name__ == '__main__': 
    #try: 
        #while True:
           # pass
                
    if len(sys.argv) < 4:
        print("client –s serverIP –p portno –l logfile –n myname")
        sys.exit()

    parse = argparse.ArgumentParser(description=' client –s serverIP –p portno –l logfile –n myname')
    parse.add_argument('-s', '--server')
    parse.add_argument('-p', '--portno', type = int)
    parse.add_argument('-l', '--logfile' )
    parse.add_argument('-n', '--name')
    
    args = parse.parse_args()
    port = int(args.portno)
    log = args.logfile
    logfile = open(log,"w")
    try: 
        client(args.server,port,args.name)
    except: 
        sys.exit()    

    sys.exit()