

usage in windows cmd 
no compile 
local host used as server for destinations. 
not intended to work outside of local host testing
 
usage of client.py and server.py tested and working 
in python 3.7.4 according to grading file.
all test cases passed on local windows machine
when commands are given one by one from a human